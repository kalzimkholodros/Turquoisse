const Menu = require('../models/Menu');

// Tüm menü öğelerini getir
exports.getAllMenuItems = async (req, res) => {
  try {
    const menuItems = await Menu.find().sort('order');
    res.json(menuItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Yeni menü öğesi oluştur
exports.createMenuItem = async (req, res) => {
  const menuItem = new Menu({
    title: req.body.title,
    description: req.body.description,
    order: req.body.order,
    subItems: req.body.subItems
  });

  try {
    const newMenuItem = await menuItem.save();
    res.status(201).json(newMenuItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Menü öğesini ID'ye göre güncelle
exports.updateMenuItem = async (req, res) => {
  try {
    const menuItem = await Menu.findById(req.params.id);
    if (!menuItem) {
      return res.status(404).json({ message: 'Menü öğesi bulunamadı' });
    }

    if (req.body.title) menuItem.title = req.body.title;
    if (req.body.description) menuItem.description = req.body.description;
    if (req.body.order) menuItem.order = req.body.order;
    if (req.body.subItems) menuItem.subItems = req.body.subItems;

    const updatedMenuItem = await menuItem.save();
    res.json(updatedMenuItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Menü öğesini ID'ye göre sil
exports.deleteMenuItem = async (req, res) => {
  try {
    const menuItem = await Menu.findById(req.params.id);
    if (!menuItem) {
      return res.status(404).json({ message: 'Menü öğesi bulunamadı' });
    }

    await menuItem.remove();
    res.json({ message: 'Menü öğesi silindi' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}; 