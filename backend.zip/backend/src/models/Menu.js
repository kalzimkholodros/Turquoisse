const mongoose = require('mongoose');

const subItemSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  order: {
    type: Number,
    default: 0
  }
});

const menuSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  order: {
    type: Number,
    default: 0
  },
  subItems: [subItemSchema]
}, {
  timestamps: true
});

module.exports = mongoose.model('Menu', menuSchema); 