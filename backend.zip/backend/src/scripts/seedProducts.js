require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('../models/Product');

const products = [
  {
    name: "React Development Kit",
    description: "Complete React development kit including React 18, Redux Toolkit, TypeScript, and Next.js. Build modern web applications with best practices and advanced features.",
    price: 99,
    image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee",
    category: "Frontend"
  },
  {
    name: "Node.js Starter Pack",
    description: "Comprehensive Node.js development package with Express.js, MongoDB integration, and RESTful API development. Perfect for building scalable backend services.",
    price: 149,
    image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479",
    category: "Backend"
  },
  {
    name: "TypeScript Bundle",
    description: "Master TypeScript with this complete bundle. Includes type system fundamentals, advanced features, and integration with popular frameworks.",
    price: 199,
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4",
    category: "Frontend"
  },
  {
    name: "AWS Cloud Package",
    description: "Comprehensive AWS cloud development package. Learn to deploy and manage applications on AWS, including EC2, S3, Lambda, and more.",
    price: 299,
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa",
    category: "Cloud"
  },
  {
    name: "Docker Essentials",
    description: "Essential Docker development toolkit. Master containerization, Docker Compose, and container orchestration fundamentals.",
    price: 399,
    image: "https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9",
    category: "DevOps"
  },
  {
    name: "Security Toolkit",
    description: "Complete security toolkit for web applications. Implement authentication, authorization, and protect against common vulnerabilities.",
    price: 499,
    image: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb",
    category: "Security"
  },
  {
    name: "GraphQL Masterclass",
    description: "Master GraphQL API development. Build efficient APIs with GraphQL, Apollo Server, and integrate with various databases.",
    price: 199,
    image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd",
    category: "Backend"
  },
  {
    name: "Vue.js Complete",
    description: "Complete Vue.js development course with Vue 3, Vuex, Vue Router, and Composition API. Build modern reactive applications.",
    price: 149,
    image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479",
    category: "Frontend"
  },
  {
    name: "MongoDB Pro",
    description: "Professional MongoDB development course. Master database design, aggregation pipeline, and performance optimization.",
    price: 249,
    image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee",
    category: "Database"
  },
  {
    name: "Redux Toolkit",
    description: "Complete Redux Toolkit course. Master state management in React applications with modern Redux practices.",
    price: 179,
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4",
    category: "Frontend"
  },
  {
    name: "Next.js Bundle",
    description: "Comprehensive Next.js development bundle. Build SEO-friendly React applications with server-side rendering.",
    price: 299,
    image: "https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9",
    category: "Frontend"
  },
  {
    name: "Testing Suite",
    description: "Complete testing suite for modern web applications. Master Jest, React Testing Library, and Cypress.",
    price: 199,
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa",
    category: "DevOps"
  },
  {
    name: "CI/CD Package",
    description: "Comprehensive CI/CD package. Implement automated testing and deployment with GitHub Actions and Jenkins.",
    price: 399,
    image: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb",
    category: "DevOps"
  },
  {
    name: "Python Dev Kit",
    description: "Complete Python development kit. Master Python programming with Django, Flask, and data science tools.",
    price: 249,
    image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd",
    category: "Backend"
  },
  {
    name: "Angular Complete",
    description: "Comprehensive Angular development course. Build enterprise-level applications with Angular and TypeScript.",
    price: 299,
    image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479",
    category: "Frontend"
  },
  {
    name: "DevOps Tools",
    description: "Essential DevOps tools and practices. Master Kubernetes, Terraform, and monitoring with Prometheus and Grafana.",
    price: 499,
    image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee",
    category: "DevOps"
  },
  {
    name: "Kubernetes Set",
    description: "Complete Kubernetes learning set. Master container orchestration and cloud-native application deployment.",
    price: 399,
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4",
    category: "DevOps"
  },
  {
    name: "Firebase Bundle",
    description: "Complete Firebase development bundle. Build serverless applications with Firebase and Google Cloud Platform.",
    price: 299,
    image: "https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9",
    category: "Cloud"
  }
];

async function seedProducts() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/turquoisse', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    
    // Clear existing products
    await Product.deleteMany({});
    
    // Insert new products
    await Product.insertMany(products);
    
    console.log('Products seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding products:', error);
    process.exit(1);
  }
}

seedProducts(); 